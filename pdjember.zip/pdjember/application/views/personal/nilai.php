<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <!-- /.container-fluid -->
    <div class="row">
        <div class="col-xl-12">

            <?= $this->session->flashdata('message'); ?>

            <a href="<?= base_url('personal/daftar_ukt'); ?>" class="btn btn-primary mb-4 btn-icon-split">
                <span class="icon text-white-40"><i class="fas fa-feather-alt"></i></span>
                <span class="text">Daftar UKT</span>
            </a>

            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Data Nilai UKT</h6>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <label for="nama" class="col-sm-3 col-form-label">Nama</label>
                        <div class="col-sm-9"><b><?= $user['nama']; ?></b></div>
                    </div>
                    <div class="form-group row">
                        <label for="nama" class="col-sm-3 col-form-label">Tingkatan</label>
                        <div class="col-sm-9"><b><?= $user['tingkatan']; ?></b></div>
                    </div>
                    <div class="form-group row">
                        <label for="nama" class="col-sm-3 col-form-label">Unit/Ranting</label>
                        <div class="col-sm-9"><b><?= $user['nama_unit']; ?></b></div>
                    </div>
                    <hr>
                    <div class="table-responsive">
                        <table class="table" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">KD Materi</th>
                                    <th scope="col">Materi UKT</th>
                                    <th scope="col">Nilai</th>
                                    <th scope="col">Keterangan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php foreach ($nilai as $p) : ?>
                                    <tr>
                                        <td><?= $i; ?></td>
                                        <td><?= $p['kd_materi']; ?></td>
                                        <td><?= $p['materi']; ?></td>
                                        <td><?= $p['rata2']; ?></td>
                                        <td><?php if ($p['rata2'] >= 60) {
                                                echo "<p class='badge badge-pill badge-success'>Lulus</p>";
                                            } else {
                                                echo "<p class='badge badge-pill badge-danger'>Tidak Lulus</p>";
                                            } ?></td>
                                    </tr>
                                <?php $i++;
                                endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- End of Main Content -->
</div>