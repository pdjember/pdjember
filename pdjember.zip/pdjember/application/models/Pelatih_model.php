<?php
class Pelatih_model extends CI_Model
{
    public function getAnggotaUnit()
    {
        $unit = $this->session->userdata('id_unit');
        $query = "SELECT `anggota`.*, `tingkatan`.`tingkatan`,`user_role`.`role`,`unit`.`nama_unit` from `anggota` 
        JOIN `tingkatan` ON `anggota`.`id_tingkatan` = `tingkatan`.`id`
        JOIN `user_role` ON `anggota`.`role_id` = `user_role`.`id`
        JOIN `unit` ON `anggota`.`id_unit` = `unit`.`id`
        WHERE `anggota`.`st_aktif` = 1 AND `anggota`.`id_unit` = '$unit' AND `anggota`.`role_id` != 1 
        ORDER BY `anggota`.`nama` ASC";

        return $this->db->query($query)->result_array();
    }

    public function getAbsensi()
    {
        $unit = $this->session->userdata('id_unit');
        $query = "SELECT absensi.*,anggota.nama,anggota.id_unit,unit.nama_unit
        FROM absensi
        JOIN anggota ON absensi.id_anggota = anggota.id
        JOIN unit ON absensi.id_unit = unit.id 
        WHERE absensi.id_unit = '$unit' ORDER BY anggota.nama ASC";

        return $this->db->query($query)->result_array();
    }
    public function simpanAbsen($data)
    {
        $th_ajaran = $this->db->get_where('th_ajaran', ['aktif' => 1])->row_array();
        $i = 0;
        foreach ($data['id'] as $id) {
            $record = array(
                'id_anggota' => $id,
                'tanggal' => date('Y-m-d'),
                'id_unit' => $this->session->userdata('id_unit'),
                'id_pelatih' => $this->session->userdata('id'),
                'id_th_ajaran' => $th_ajaran['id']
            );
            $this->db->insert('absensi', $record);
            $i++;
        }
    }

    public function getDataFisik()
    {
        $unit = $this->session->userdata('id_unit');
        $query = "SELECT `anggota`.`id`,`anggota`.`nama`,`anggota`.`st_aktif`,`ability`.* from `ability`
        JOIN `anggota` ON `anggota`.`id` = `ability`.`id_anggota`
        WHERE `anggota`.`st_aktif`=1 AND `anggota`.`id_unit` = '$unit' ORDER BY `anggota`.`nama` ASC";
        return $this->db->query($query)->result_array();
    }
}
