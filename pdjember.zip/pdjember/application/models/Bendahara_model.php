<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Bendahara_model extends CI_Model
{
    public function getPemasukanCabang()
    {
        $query = "SELECT `kas_cabang`.*,`th_ajaran`.`th_ajaran`, `th_ajaran`.`semester` FROM `kas_cabang` 
        JOIN `th_ajaran` ON `th_ajaran`.`id` = `kas_cabang`.`id_th_ajaran`
        WHERE `kas_cabang`.`jenis_trx`='D' ORDER BY `kas_cabang`.`tgl_trx` DESC";

        return $this->db->query($query)->result_array();
    }

    public function getJmlPemasukanCabang()
    {
        $query = "SELECT SUM(`nominal`) AS `jml_pemasukan` FROM `kas_cabang` 
        WHERE `jenis_trx`='D'";

        return $this->db->query($query)->result_array();
    }

    public function getPengeluaranCabang()
    {
        $query = "SELECT `kas_cabang`.*,`th_ajaran`.`th_ajaran`, `th_ajaran`.`semester` FROM `kas_cabang` 
        JOIN `th_ajaran` ON `th_ajaran`.`id` = `kas_cabang`.`id_th_ajaran`
        WHERE `kas_cabang`.`jenis_trx`='C' ORDER BY `kas_cabang`.`tgl_trx` DESC";

        return $this->db->query($query)->result_array();
    }

    public function getJmlPengeluaranCabang()
    {
        $query = "SELECT SUM(`nominal`) AS `jml_pengeluaran` FROM `kas_cabang` 
        WHERE `jenis_trx`='C'";

        return $this->db->query($query)->result_array();
    }

    public function printLaporanCabangAll()
    {
        $query = "SELECT * FROM `kas_cabang` 
        WHERE 1 ORDER BY `tgl_trx` ASC";

        return $this->db->query($query)->result();
    }

    function printPemasukanCabangAll()
    {
        $query = "SELECT sum(`nominal`) as jumlah FROM `kas_cabang` 
        WHERE `jenis_trx`='D'";

        return $this->db->query($query)->result();
    }

    function printPengeluaranCabangAll()
    {
        $query = "SELECT sum(`nominal`) as jumlah FROM `kas_cabang` 
        WHERE `jenis_trx`='C'";

        return $this->db->query($query)->result();
    }



    public function getPemasukanUnit()
    {
        $unit = $this->session->userdata('id_unit');
        $query = "SELECT `kas_unit`.*,`th_ajaran`.`th_ajaran`, `th_ajaran`.`semester` FROM `kas_unit` 
        JOIN `th_ajaran` ON `th_ajaran`.`id` = `kas_unit`.`id_th_ajaran`
        WHERE `id_unit`='$unit' AND `kas_unit`.`jenis_trx`='D' ORDER BY `kas_unit`.`tgl_trx` DESC";

        return $this->db->query($query)->result_array();
    }

    public function getJmlPemasukanUnit()
    {
        $unit = $this->session->userdata('id_unit');
        $query = "SELECT SUM(`nominal`) AS `jml_pemasukan` FROM `kas_unit` 
        WHERE `id_unit`='$unit' AND `jenis_trx`='D'";

        return $this->db->query($query)->result_array();
    }

    public function getPengeluaranUnit()
    {
        $unit = $this->session->userdata('id_unit');
        $query = "SELECT `kas_unit`.*,`th_ajaran`.`th_ajaran`, `th_ajaran`.`semester` FROM `kas_unit` 
        JOIN `th_ajaran` ON `th_ajaran`.`id` = `kas_unit`.`id_th_ajaran`
        WHERE `id_unit`='$unit' AND `kas_unit`.`jenis_trx`='C' ORDER BY `kas_unit`.`tgl_trx` DESC";

        return $this->db->query($query)->result_array();
    }

    public function getJmlPengeluaranUnit()
    {
        $unit = $this->session->userdata('id_unit');
        $query = "SELECT SUM(`nominal`) AS `jml_pengeluaran` FROM `kas_unit` 
        WHERE `id_unit`='$unit' AND `jenis_trx`='C'";

        return $this->db->query($query)->result_array();
    }

    public function printLaporanUnitAll()
    {
        $unit = $this->session->userdata('id_unit');
        $query = "SELECT * FROM `kas_unit` 
        WHERE `id_unit` = '$unit' ORDER BY `tgl_trx` ASC";

        return $this->db->query($query)->result();
    }

    function printPemasukanUnitAll()
    {
        $unit = $this->session->userdata('id_unit');
        $query = "SELECT sum(`nominal`) as jumlah FROM `kas_unit` 
        WHERE `id_unit` = '$unit' AND `jenis_trx`='D'";

        return $this->db->query($query)->result();
    }

    function printPengeluaranUnitAll()
    {
        $unit = $this->session->userdata('id_unit');
        $query = "SELECT sum(`nominal`) as jumlah FROM `kas_unit` 
        WHERE `id_unit` = '$unit' AND `jenis_trx`='C'";

        return $this->db->query($query)->result();
    }

    public function getLapCabang()
    {
        $query = "SELECT `kas_cabang`.*,`th_ajaran`.`th_ajaran`, `th_ajaran`.`semester` FROM `kas_cabang` 
        JOIN `th_ajaran` ON `th_ajaran`.`id` = `kas_cabang`.`id_th_ajaran` WHERE 1";

        return $this->db->query($query)->result_array();
    }

    public function getLapUnit()
    {
        $query = "SELECT `kas_unit`.*,`th_ajaran`.`th_ajaran`, `th_ajaran`.`semester` FROM `kas_unit` 
        JOIN `th_ajaran` ON `th_ajaran`.`id` = `kas_unit`.`id_th_ajaran` WHERE 1";

        return $this->db->query($query)->result_array();
    }
}
